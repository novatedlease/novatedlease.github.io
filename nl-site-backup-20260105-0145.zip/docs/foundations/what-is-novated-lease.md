# What is a novated lease, really?

_TODO: consolidated article._
