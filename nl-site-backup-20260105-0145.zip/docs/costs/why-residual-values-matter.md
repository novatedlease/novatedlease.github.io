# All about residual values

Residual value is one of the **most important variables** in a novated lease, and misunderstanding it is a major reason people misjudge whether a lease is good value.

Unfortunately, some novated lease providers fail to adequately emphasise or explain residual values to first-time lessees. As a result, some people are surprised to discover that they still owe tens of thousands of dollars at the end of the lease if they wish to keep the vehicle.

---

## What a residual value actually is

In a novated lease, the residual value (sometimes called a balloon payment) is the **amount you still owe at the end of the lease term** if you want to keep the vehicle.

It is not optional.

At the end of the lease, you must either:

- pay the residual and keep the car, or  
- refinance the residual into a new lease or loan, or  
- sell or return the car and use the proceeds to clear the residual.  

Regardless of which path you take, the residual is a **real financial liability** that does not disappear.

---

## The ATO’s intent behind residual values

Many people understand *what* the residual or balloon payment is, but struggle to understand **why it exists at all**.

The answer is simple: **because the ATO requires it**.

The concept of a mandatory minimum residual value was introduced by the ATO decades ago, first in **[IT 28 (1960)][it28]** and later clarified in **[TD 93/142][td93142]** (with subsequent addendums).

You *can* read those rulings directly, but they are dense, technical, and heavy on legal terminology.

The short version is this:

> Residual values exist to ensure that leases are **genuine leases**, not disguised loans.

From the ATO’s perspective, a lease is meant to be meaningfully different from a loan.

If leases were allowed to run down the value of an asset to a token amount (for example, claiming that a car is “worth $50” after a two-year lease), they would effectively become **fully tax-deductible loans in disguise**.

To prevent this, the ATO enforces minimum residual values that:

- assume the asset still has **some remaining economic value** at the end of the lease, and  
- very coarsely correspond to real-world depreciation over time.

In other words, residual values exist to **protect the tax system from abuse**. They ensure that lease payments broadly reflect depreciation of the asset, rather than the full asset value.

---

## Residual values are constrained, not arbitrary

Residual values are not set at random.

They are constrained by **ATO minimum residual guidelines**, which specify the *lowest* residual value permitted for a given lease term.

In particular:

- 1 year lease → 65.63% residual  
- 2 year lease → 56.25% residual  
- 3 year lease → 46.88% residual  
- 4 year lease → 37.50% residual  
- 5 year lease → 28.13% residual  

Providers may choose to set residuals **above** these minimums, but they cannot set them below.

---

## Residual value is deferred payment, not savings

A common psychological mistake is to treat the residual as a distant problem:

> “I’ll worry about that later.”

From a financial perspective, this is incorrect.

A novated lease simply divides the cost of the car into:

- amounts paid during the lease term, and  
- a large lump sum paid at the end.

Ignoring the residual is equivalent to ignoring part of the purchase price.

---

## Residual values and EV novated leases

Residual values are particularly important for EV novated leases.

Because EV novated leases are often FBT-exempt:

- more of the lease is funded pre-tax  
- take-home pay impacts look especially favourable  
- the residual can feel psychologically distant  

None of this changes the mathematics.

The residual remains a **post-tax obligation** that must be dealt with at the end of the lease.

---

## Market value ≠ residual value

Another common misconception is that the residual reflects the *expected* future market value of the car.

It does not.

The residual is an **accounting construct**, not a valuation estimate or guarantee.

As a result, the car’s market value and the end-of-lease residual value are **independent variables**. When evaluating the total financial outcome of a novated lease, both must be considered separately.

---

## How residual values work when a lease is extended

A common misunderstanding is how residual values behave when a novated lease is extended (for example, 1 + 1 + 1 years).

When you extend a lease, the car’s residual value does **not** compound on itself.

In other words, it does **not** become:

> 65.63% of 65.63% of 65.63%

Instead, the residual continues to follow the **original ATO residual table**, calculated as a percentage of the **original vehicle value**.

For example:

- end of year 1 → ~65.63% of original value  
- end of year 2 → ~56.25% of original value  
- end of year 3 → ~46.88% of original value  

This is true even if the lease is structured as consecutive extensions rather than a single multi-year lease.

The ATO made this explicit in **TD 93/142**, including worked examples (see Example 3). This specific clarification around lease extensions was reinforced in the 2021 addendum.

<https://www.ato.gov.au/law/view/document?docid=TXD/TD93142/NAT/ATO/00001>

It is worth noting that **some novated lease providers and financiers still apply a “repeated 65.63%” style calculation** when leases are extended (i.e. compounding the residual on the prior residual rather than referencing the original vehicle value), which results in higher overall saving due to higher portion of the vehicle cost being paid under tax-advantaged lease. 

This approach sits in a **legally murky and risky area**, and risks the lease no longer meeting the ATO’s definition of a genuine lease.

---

## The key takeaway

If you remember nothing else:

> **Residual values are an ATO-enforced constraint designed to prevent leases from becoming tax-deductible loans.**

They represent **deferred payment** for part of the car’s cost that was never eligible for tax savings.

[td93142]: https://www.ato.gov.au/law/view/document?LocID=%22TXD%2FTD93142%2FNAT%2FATO%22&PiT=99991231235958  
[it28]: https://www.ato.gov.au/law/view/document?DocID=ITR/IT28/NAT/ATO/00001