# Hospitals and NFP novated leases

_TODO: consolidated article._
