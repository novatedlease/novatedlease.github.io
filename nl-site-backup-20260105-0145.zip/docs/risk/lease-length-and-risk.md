# Lease length, residuals, and risk

_TODO: consolidated article._
