# Job loss, write-offs, and insurance

_TODO: consolidated article._
