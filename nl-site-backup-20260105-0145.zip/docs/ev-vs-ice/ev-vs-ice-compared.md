# EV and ICE novated leases functionally different products

A common source of confusion in discussions about novated leasing is the assumption that:

> an EV novated lease and an ICE novated lease are essentially the same product,  
> just with different cars.

This assumption is wrong.

While both arrangements are called “novated leases”, **they operate under fundamentally different tax mechanics**, and therefore behave very differently in practice.

Failing to separate the two leads to poor comparisons and misleading conclusions. It also explains why many comments confidently assert that “novated leases are never worth it”, often based on outdated experience with ICE vehicles and without any awareness of the FBT exemption that applies to eligible EVs.

---

## FBT exemption for electric vehicles

The single most important distinction is this:

- **Eligible EV novated leases are exempt from Fringe Benefits Tax (FBT)**.
- **Plug-in hybrid EVs were also FBT-exempt prior to 1 April 2025, with all pre-existing leases grandfathered until the end of their term**.
- **ICE novated leases are not**.

This is not a minor technicality. **FBT exemption fundamentally changes the economics of the arrangement.**

---

## How ICE novated leases actually work

For ICE vehicles, the provision of a car under a novated lease creates a taxable fringe benefit, which is a tax liability for **the employer**.

Because employers generally do not want to pay FBT themselves, ICE novated leases are almost always structured to **eliminate the employer’s FBT liability**.

This is done using the **Employee Contribution Method (ECM)**:

- a substantial portion of lease repayments and running costs is paid using **post-tax income**
- this reduces the taxable value of the benefit
- and brings the employer’s FBT payable down to zero

The practical consequences are:

- limited pre-tax benefit, as only a smaller portion of the lease is now funded pre-tax
- modest tax savings at best
- increased structural complexity
- and often an outcome that is only marginally better (if at all) than straightforward alternatives

This is why many people conclude that “novated leases aren’t worth it”, based largely on their experience with ICE vehicles.

---

## What changed with EV novated leases

For eligible EVs, the car benefit itself is **FBT-exempt**.

This removes the need for ECM entirely.

As a result:

- a much larger proportion of costs can be funded using **pre-tax income**
- income tax reductions are far more substantial

This is a deliberate policy choice introduced in 2022 to encourage EV uptake.

However, this policy change applies to **EVs (subject to future review), and previously to PHEVs (up to 1 April 2025)**; not to novated leasing as a general concept.

---

## Why people conclude “novated leases are good now”

Many people look at EV novated lease figures and infer:

> “Novated leases are now good deals.”

What has actually changed is narrower than that:

- novated leasing as a structure has not fundamentally changed
- the **tax treatment of a specific class of vehicles** has changed

EV novated leases appear more attractive because:

- FBT is removed from the equation
- more costs are funded with pre-tax income
- income tax reductions become much more significant

ICE vehicles continue to operate under the original rules.

---

## RFBA and adjusted taxable income: where the trade-off appears

Although EV novated leases are FBT-exempt, the benefit is still reported as a **Reportable Fringe Benefits Amount (RFBA)**.

[As discussed elsewhere](../../foundations/fbt-rfba-ati-explained/#4-what-is-rfba) in this guide:

- RFBA does not affect income tax
- but it *does* affect adjusted taxable income (ATI)
- which in turn affects HECS/HELP repayments, childcare subsidy, Division 293 tax, and other means-tested outcomes

ICE novated leases, by contrast:

- often generate little or no RFBA once ECM is applied
- but achieve this by shifting more cost into post-tax payments

This creates a genuine trade-off:

- **EV novated leases**:  
  lower income tax (and therefore cheaper lease), but often higher adjusted taxable income (and therefore worse outcomes for means-tested subsidies)

- **ICE novated leases**:  
  higher income tax (and therefore costlier lease), but typically little or no RFBA and hence a smaller impact on adjusted taxable income (often preserving means-tested benefits)

As a general observation, the take-home pay benefit of an EV novated lease often outweighs the reduction in means-tested subsidies. However, this is highly dependent on individual circumstances and should always be calculated rather than assumed.

---


## When ICE novated leases might still make sense

None of the above implies that ICE novated leases are *always* irrational.

They can still make sense in specific, relatively narrow circumstances, typically involving some combination of:

- a very short lease term (e.g. 12 months)
- a high marginal tax rate
- unusually high running costs (for example, very high annual mileage)

In such cases, it is possible to calculate a modest net benefit from an ICE novated lease (compared to funding the same vehicle with offset cash or a car loan). 

However, for the same individuals and usage patterns, the **numerical benefit is usually substantially larger under an EV novated lease**, assuming eligibility and similar vehicle value.

---

## The correct mental model

A more accurate way to think about novated leasing today is:

> **There are now two different products that happen to share the same name.**

- EV novated leases are a **policy-driven tax concession delivered through the novated lease structure**.
- ICE novated leases are the **original novated lease product, constrained by the impact of FBT**.

Discussing them as if they are the same thing obscures the real trade-offs and risks conflating the pros and cons of each product.

---

## The key takeaway

If you remember nothing else:

> **EV and ICE novated leases should be analysed as different products, not as variations of the same one.**