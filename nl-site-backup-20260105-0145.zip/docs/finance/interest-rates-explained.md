# Why novated lease interest rates look high

_TODO: consolidated article._
