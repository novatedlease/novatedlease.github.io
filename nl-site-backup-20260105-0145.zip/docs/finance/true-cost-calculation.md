# How to calculate the true cost of a novated lease

_TODO: consolidated article._
