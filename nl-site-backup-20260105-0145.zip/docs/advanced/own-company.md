# Using your own company instead of a novated lease

_TODO: consolidated article._
