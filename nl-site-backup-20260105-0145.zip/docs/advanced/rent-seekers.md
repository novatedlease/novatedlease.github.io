# Are novated lease companies rent-seekers?

_TODO: consolidated article._
